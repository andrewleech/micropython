---
name: micropython-memory
description: Comprehensive guide to MicroPython's memory management system, including garbage collection, heap allocation, object retention, and optimization strategies. This skill should be used when debugging memory issues, optimizing memory usage, understanding object lifecycle, or implementing memory-efficient code in MicroPython.
---

# MicroPython Memory Management

This skill provides in-depth knowledge of MicroPython's memory management system to help understand object retention, garbage collection behavior, and memory optimization strategies.

## Purpose

To provide comprehensive understanding of:
- How MicroPython allocates and manages memory
- When and why objects are retained or collected
- How to diagnose and prevent memory fragmentation
- Strategies for memory-efficient code

## When to Use This Skill

Invoke this skill when:
- Debugging memory leaks or out-of-memory errors
- Optimizing memory usage in constrained environments
- Understanding why certain objects persist or are collected
- Implementing memory-efficient data structures
- Analyzing heap fragmentation issues
- Working with root pointers and persistent objects
- Planning memory allocation strategies
- Working with C modules and understanding soft reset behavior
- Implementing C extensions that manage Python objects

## Core Concepts

### Object Model
All MicroPython objects are represented as `mp_obj_t` (typically word-sized). Some objects store values directly without heap allocation:
- Small integers (tagged with LSB = 1)
- Interned strings (tagged 010)
- Immediate values: None, True, False (tagged 110)
- Concrete heap objects (tagged 00, pointer to heap)

### Garbage Collection
MicroPython uses Mark and Sweep algorithm (non-relocating, non-compacting):
1. **Mark phase**: Traverse from root pointers, marking all reachable objects
2. **Sweep phase**: Reclaim memory from unmarked objects

**CRITICAL: Objects are NEVER relocated or moved in memory. The GC does NOT compact the heap.**
- Object pointers remain stable throughout object lifetime
- Fragmentation is permanent until objects are freed
- No defragmentation occurs - memory layout never changes

### Root Pointers
Objects remain in memory if reachable from root pointers:
- Module-level variables (main module globals)
- REPL globals
- Stack variables in active functions
- C-level roots registered with `MP_REGISTER_ROOT_POINTER`

## Using Reference Documentation

For detailed information, consult the reference files:

### Memory Model Details
```
Read references/memory-model.md
```
Contains: Object representation, heap structure, pointer tagging, allocation units

### Garbage Collection Behavior
```
Read references/gc-behavior.md
```
Contains: GC algorithm details, root pointer system, retention rules, trigger conditions

### Optimization Patterns
```
Read references/optimization-patterns.md
```
Contains: Fragmentation reduction, pre-allocation strategies, gc.collect() usage, memory monitoring

### C-Level Memory Interface
```
Read references/c-memory-interface.md
```
Contains: C API for GC, object retention from C, soft reset behavior, memory allocation patterns

## Quick Reference

### Key Functions
- `gc.collect()` - Manually trigger garbage collection
- `gc.mem_alloc()` - Bytes allocated by Python code
- `gc.mem_free()` - Bytes available for allocation
- `gc.threshold(amount)` - Set automatic GC threshold

### Memory Tips
- Small integers and immediates never allocate heap
- Regular `gc.collect()` reduces fragmentation (~1ms vs several ms when forced)
- Pre-allocate buffers to avoid repeated allocations
- Objects in module scope are never collected

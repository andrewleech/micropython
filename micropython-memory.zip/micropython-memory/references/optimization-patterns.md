# Memory Optimization Patterns

## Why Fragmentation Matters

**CRITICAL: MicroPython's GC does NOT relocate or compact memory.**

This means:
- Once the heap becomes fragmented, it stays fragmented until objects are freed
- Large allocations can fail even with sufficient total free memory
- Gaps between objects are permanent until those objects are collected
- Prevention is the only strategy - fragmentation cannot be fixed retroactively

Example fragmentation scenario:
```
Heap: [obj1][free][obj2][free][obj3][free]
Total free: 300 bytes (3 x 100 byte gaps)
Large allocation request: 250 bytes
Result: FAILS - no contiguous 250 byte block exists
```

The GC will NOT move obj1, obj2, obj3 to create contiguous space. The allocation fails despite 300 bytes being free.

## Preventing Fragmentation

### Regular Collection Strategy
```python
import gc

# Collect frequently during idle times
def idle_task():
    gc.collect()  # ~1ms when not under pressure
    # ... other idle work ...
```

Benefits:
- Prevents fragmentation buildup
- Predictable pause times
- Avoids emergency collections

### Threshold Tuning
```python
# Collect after every 8KB allocated
gc.threshold(8192)

# Monitor and adjust
initial = gc.mem_alloc()
# ... run typical workload ...
peak = gc.mem_alloc()
gc.threshold((peak - initial) // 2)  # Collect at 50% of typical usage
```

### Large Allocation Patterns
```python
# BAD: Interleaved allocations fragment heap
for i in range(100):
    small_obj = create_small()
    large_obj = create_large()
    process(small_obj, large_obj)

# GOOD: Group similar sizes
small_objs = [create_small() for i in range(100)]
large_objs = [create_large() for i in range(100)]
for s, l in zip(small_objs, large_objs):
    process(s, l)
```

## Pre-allocation Strategies

### Buffer Reuse
```python
# BAD: Allocates new buffer each time
def read_sensor():
    return sensor.read()  # Creates new bytes object

# GOOD: Reuse pre-allocated buffer
class SensorReader:
    def __init__(self):
        self.buf = bytearray(100)

    def read(self):
        sensor.readinto(self.buf)
        return self.buf
```

### Array Pre-allocation
```python
# BAD: List grows dynamically
data = []
for i in range(1000):
    data.append(read_value())

# GOOD: Pre-allocate array
import array
data = array.array('i', [0] * 1000)
for i in range(1000):
    data[i] = read_value()
```

### Circular Buffers
```python
# Use micropython.RingIO for efficient circular buffer
from micropython import RingIO

class DataLogger:
    def __init__(self, size=1024):
        self.ring = RingIO(bytearray(size))

    def log(self, data):
        self.ring.write(data)

    def get_recent(self, n):
        return self.ring.read(n)
```

## Avoiding Allocations

### Use const() for Constants
```python
# BAD: Runtime lookup and possible allocation
BUFFER_SIZE = 256
GPIO_PIN = 10

# GOOD: Compile-time substitution
from micropython import const
BUFFER_SIZE = const(256)
GPIO_PIN = const(10)
```

### Cache Object References
```python
# BAD: Repeated lookups may allocate
def process_data(self):
    for i in range(1000):
        self.buffer[i] = self.sensor.value()

# GOOD: Cache references
def process_data(self):
    buf = self.buffer
    read_val = self.sensor.value
    for i in range(1000):
        buf[i] = read_val()
```

### Memoryview for Slicing
```python
# BAD: Slice creates copy
def process_chunk(data):
    chunk = data[100:200]  # Allocates new bytes
    return sum(chunk)

# GOOD: Memoryview references original
def process_chunk(data):
    mv = memoryview(data)
    chunk = mv[100:200]  # No allocation
    return sum(chunk)
```

## Memory Monitoring

### Track Memory Usage
```python
import gc

def memory_stats():
    gc.collect()
    print(f"Allocated: {gc.mem_alloc()} bytes")
    print(f"Free: {gc.mem_free()} bytes")
    print(f"Total: {gc.mem_alloc() + gc.mem_free()} bytes")
```

### Detect Leaks
```python
import gc

class MemoryMonitor:
    def __init__(self):
        gc.collect()
        self.baseline = gc.mem_alloc()

    def check(self, label=""):
        gc.collect()
        current = gc.mem_alloc()
        delta = current - self.baseline
        print(f"{label}: {delta:+d} bytes")
        return delta

# Usage
mon = MemoryMonitor()
create_objects()
mon.check("After creation")  # Should show increase
destroy_objects()
mon.check("After cleanup")   # Should return to ~0
```

### Profile Allocations
```python
import gc
import time

def profile_function(func, *args):
    gc.collect()
    start_mem = gc.mem_alloc()
    start_time = time.ticks_ms()

    result = func(*args)

    gc.collect()
    end_mem = gc.mem_alloc()
    end_time = time.ticks_ms()

    print(f"Memory: {end_mem - start_mem} bytes")
    print(f"Time: {end_time - start_time} ms")
    return result
```

## String and Bytes Optimization

### Use Bytes for Performance
```python
# Slower: String operations check interning
text = "hello" + "world"

# Faster: Bytes skip interning
data = b"hello" + b"world"
```

### Format String Efficiently
```python
# BAD: Multiple concatenations
msg = "Temp: " + str(temp) + " Humidity: " + str(hum)

# GOOD: Single format operation
msg = "Temp: {} Humidity: {}".format(temp, hum)

# BETTER: f-strings (if supported)
msg = f"Temp: {temp} Humidity: {hum}"
```

## Emergency Recovery

### Handle OOM Gracefully
```python
import gc

def safe_allocate(size):
    try:
        return bytearray(size)
    except MemoryError:
        gc.collect()
        try:
            return bytearray(size)
        except MemoryError:
            # Emergency cleanup
            clear_caches()
            gc.collect()
            return bytearray(size)  # Final attempt
```

### Reserve Emergency Memory
```python
# Pre-allocate emergency buffer
EMERGENCY_BUFFER = bytearray(1024)

def emergency_handler():
    global EMERGENCY_BUFFER
    # Free emergency buffer for use
    EMERGENCY_BUFFER = None
    gc.collect()

    # Do emergency cleanup
    log_error()
    save_state()

    # Reallocate if possible
    try:
        EMERGENCY_BUFFER = bytearray(1024)
    except:
        pass
```

## Platform-Specific Optimizations

### ESP32
```python
# Use PSRAM for large buffers
import esp32
esp32.heap_caps_get_free_size(esp32.HEAP_CAP_SPIRAM)
```

### STM32
```python
# Access hardware directly to avoid allocations
import stm
from micropython import const

REG_ADDR = const(stm.GPIOA + stm.GPIO_ODR)
machine.mem32[REG_ADDR] ^= (1 << 5)  # Toggle pin
```

## Best Practices Summary

1. **Pre-allocate** buffers and reuse them
2. **Call gc.collect()** during idle periods, not critical sections
3. **Use const()** for all numeric constants
4. **Cache** object attribute lookups in tight loops
5. **Monitor** memory usage during development
6. **Group** allocations by size to reduce fragmentation
7. **Use bytes** instead of strings for performance-critical code
8. **Set gc.threshold()** based on application profile
9. **Handle MemoryError** gracefully with fallback strategies
10. **Profile** memory usage of critical functions
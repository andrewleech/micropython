# MicroPython Memory Model

## Object Representation (mp_obj_t)

Every MicroPython object is represented by `mp_obj_t`, which is typically word-sized:
- 32-bit on STM32, nRF, ESP32, Unix x86
- 64-bit on Unix x64
- Can be larger for certain representations (e.g., OBJ_REPR_D)

## Pointer Tagging System

Since pointers are word-aligned, the lower bits store type information:

### Small Integers
```
********|********|********|*******1
```
- Tagged with LSB = 1
- Integer value stored in upper bits
- NO heap allocation required
- Range limited by available bits (31 bits on 32-bit systems)

### Interned Strings
```
********|********|********|*****010
```
- Tagged with 010
- Points to pre-allocated string data
- NO additional heap allocation for string object itself

### Immediate Objects
```
********|********|********|*****110
```
- Tagged with 110
- Represents None, True, False
- NO heap allocation required

### Concrete Heap Objects
```
********|********|********|******00
```
- Tagged with 00 (lower 2 bits zero due to alignment)
- Contains pointer to actual object on heap
- Requires heap allocation

## Heap Structure

### Allocation Units
- **Block**: Smallest allocation unit
- Size: 4 machine words
  - 16 bytes on 32-bit systems
  - 32 bytes on 64-bit systems

### Object Layout
```
+++++++++++++
+ type      + } Object header
+++++++++++++
+ data      + } Object items
+ ...       +
+++++++++++++
```

Every heap object has:
1. Type field in header (identifies object type)
2. Object-specific data

### Bitmap Tracking
- Separate bitmap structure tracks block allocation states
- 2 bits per block for state information
- States include:
  - ATB (Allocation Table Byte): Normal block
  - FREE: Available for allocation
  - HEAD: Start of multi-block allocation
  - TAIL: Continuation of multi-block allocation
  - MARK: Marked during GC (live object)
  - FTB (Finalizer Table Byte): Has finalizer

## Memory Allocation Process

1. **Request arrives** for N bytes
2. **Round up** to nearest block size (multiple of 4 words)
3. **Search heap** for contiguous free blocks
4. **If found**: Mark blocks as allocated, return pointer
5. **If not found**: Trigger garbage collection
6. **After GC**: Retry allocation
7. **If still fails**: Raise MemoryError

## Special Cases

### Zero-Cost Objects
These never allocate heap memory:
- Small integers (within tagged range)
- Pre-existing interned strings
- None, True, False
- Empty tuple (pre-allocated singleton)

### String Interning
- Strings are checked for interning during creation
- If identical string exists, reuse it
- Saves memory but adds lookup overhead
- Use `bytes` for performance-critical code (skips interning)

### Buffer Protocol Objects
Objects supporting buffer protocol:
- `bytearray`
- `array.array`
- `memoryview`
- Direct memory access without copying
- Efficient for I/O operations

## Memory Regions

### Stack
- Function call frames
- Local variables (references to objects)
- Limited size, overflow causes crash

### Heap
- Dynamic object allocation
- Managed by garbage collector
- Size configured at compile/runtime

### Static/BSS
- Global C variables
- Root pointers registered here
- Not garbage collected

## Important Implementation Details

1. **Non-relocating GC**: Objects are NEVER moved or relocated in memory
2. **No memory compaction**: Heap is NEVER compacted to defragment
3. **Stable pointers**: Object pointers remain valid for object's entire lifetime
4. **Allocation is expensive**: Each allocation requires heap search and may trigger GC
5. **Fragmentation is permanent**: Gaps between objects persist until objects are freed
6. **GC is stop-the-world**: All execution pauses during collection
7. **Reference counting not used**: Pure mark-and-sweep algorithm

**The non-relocating nature means:**
- C code can safely cache `mp_obj_t` pointers across GC cycles
- No write barriers needed
- Fragmentation cannot be fixed retroactively
- Prevention is the only fragmentation strategy
# C-Level Memory Management

## Non-Relocating GC Guarantee

**MicroPython's GC is non-relocating and non-compacting.**

This provides stability for C code:
- Object pointers NEVER change after allocation
- Safe to cache `mp_obj_t` values across GC cycles
- No write barriers needed when storing object references
- Heap fragmentation is permanent until objects are freed

C code benefits:
```c
// This pointer remains valid until object is collected
mp_obj_t obj = mp_obj_new_list(0, NULL);

// Even after GC, pointer is still valid
gc_collect();

// Still safe to use
mp_obj_list_append(obj, mp_const_none);  // OK
```

Contrast with relocating GCs (NOT MicroPython):
```c
// In a relocating GC (like Java/Go), this would be UNSAFE
// because GC might move the object and invalidate the pointer
// MicroPython does NOT do this
```

## Triggering GC from C

### Direct Collection
```c
#include "py/gc.h"

// Trigger garbage collection from C
gc_collect();

// With verbose output (prints statistics)
#if MICROPY_PY_GC
mp_obj_t gc_module = mp_module_get_loaded(MP_QSTR_gc);
mp_obj_t collect_fn = mp_load_attr(gc_module, MP_QSTR_collect);
mp_call_function_1(collect_fn, mp_const_true);  // Verbose=True
#endif
```

### Safe Collection Points
```c
// During allocation failure
void *ptr = m_malloc(size);
if (ptr == NULL) {
    gc_collect();
    ptr = m_malloc(size);
    if (ptr == NULL) {
        mp_raise_msg(&mp_type_MemoryError, MP_ERROR_TEXT("out of memory"));
    }
}
```

## Ensuring Object Retention

### Temporary Protection
```c
// Protect object during C function execution
mp_obj_t protected_obj = mp_obj_new_str("data", 4);

// Push to GC stack to prevent collection
gc_collect_root(&protected_obj, 1);

// ... do work that might trigger GC ...

// Object automatically unprotected when function returns
```

### Permanent Root Pointers
```c
// In module or port code
MP_REGISTER_ROOT_POINTER(mp_obj_t my_persistent_object);

// Initialize in module init
void mymodule_init(void) {
    MP_STATE_VM(my_persistent_object) = mp_obj_new_dict(0);
}

// Access via MP_STATE_VM macro
mp_obj_t get_persistent(void) {
    return MP_STATE_VM(my_persistent_object);
}
```

### Module Globals
```c
// Objects in module globals dict are roots
STATIC const mp_rom_map_elem_t mymodule_globals_table[] = {
    { MP_ROM_QSTR(MP_QSTR___name__), MP_ROM_QSTR(MP_QSTR_mymodule) },
    { MP_ROM_QSTR(MP_QSTR_persistent_list), MP_ROM_PTR(&my_list_obj) },
};

// This list object won't be collected
STATIC mp_obj_list_t my_list_obj = {{&mp_type_list}, 0, 0, NULL};
```

## Checking Object Retention

### Test if Object Will Survive GC
```c
// Check if object is reachable from roots
bool will_survive_gc(mp_obj_t obj) {
    // Object survives if:
    // 1. It's an immediate (small int, True/False/None)
    if (mp_obj_is_immediate(obj)) {
        return true;
    }

    // 2. It's in a root pointer
    // 3. It's referenced by another surviving object
    // (No direct API - must trace manually or test empirically)

    // Empirical test (expensive):
    gc_info_t info;
    gc_info(&info);
    size_t before = info.used;
    gc_collect();
    gc_info(&info);
    size_t after = info.used;

    // If object still valid and memory usage similar, likely survived
    // But this is not reliable for individual objects
    return mp_obj_is_type(obj, mp_obj_get_type(obj));
}
```

### Object Type Checks
```c
// Check if object needs heap allocation
bool needs_heap(mp_obj_t obj) {
    return !mp_obj_is_immediate(obj);
}

// Check if immediate (no heap)
bool mp_obj_is_immediate(mp_obj_t obj) {
    return (mp_obj_is_small_int(obj) ||
            mp_obj_is_qstr(obj) ||
            obj == mp_const_none ||
            obj == mp_const_false ||
            obj == mp_const_true);
}
```

## Memory Allocation from C

### Standard Allocation
```c
// Allocate with GC tracking
void *ptr = m_malloc(size);          // Raises on failure
void *ptr = m_malloc0(size);         // Zero-initialized
void *ptr = m_malloc_maybe(size);    // Returns NULL on failure

// Reallocate
ptr = m_realloc(ptr, old_size, new_size);

// Free
m_free(ptr, size);  // Must provide original size
```

### Object Creation
```c
// These allocate on heap and are GC-tracked
mp_obj_t list = mp_obj_new_list(0, NULL);
mp_obj_t dict = mp_obj_new_dict(0);
mp_obj_t str = mp_obj_new_str("hello", 5);
mp_obj_t bytes = mp_obj_new_bytes((uint8_t*)"data", 4);

// Pre-allocated/immediate (no heap)
mp_obj_t small_int = MP_OBJ_NEW_SMALL_INT(42);
mp_obj_t none = mp_const_none;
mp_obj_t true_val = mp_const_true;
```

### Type-Specific Allocation
```c
// Allocate custom object
typedef struct _my_obj_t {
    mp_obj_base_t base;
    uint32_t data;
} my_obj_t;

my_obj_t *self = m_new_obj(my_obj_t);
self->base.type = &my_type;
self->data = 123;

// Allocate with flexible array
typedef struct _buffer_obj_t {
    mp_obj_base_t base;
    size_t len;
    uint8_t data[];  // Flexible array member
} buffer_obj_t;

buffer_obj_t *buf = m_new_obj_var(buffer_obj_t, uint8_t, 256);
buf->base.type = &buffer_type;
buf->len = 256;
```

## Stack vs Heap Objects

### Stack Objects (Temporary)
```c
// Stack-allocated, must protect if GC might run
void process_data(void) {
    mp_obj_t temp_list = mp_obj_new_list(0, NULL);

    // If this function might trigger GC, protect the object
    mp_obj_t protected[] = {temp_list};
    gc_collect_root(protected, 1);

    // Use temp_list...
    potentially_allocating_function();

    // Protection ends when function returns
}
```

### Static Objects (Global)
```c
// Static storage, but must register as root
STATIC mp_obj_t global_cache = MP_OBJ_NULL;

// Register as root pointer
MP_REGISTER_ROOT_POINTER(mp_obj_t global_cache);

// Or use const for compile-time objects
STATIC const mp_obj_str_t const_str = {{&mp_type_str}, 0, 5, (const byte*)"hello"};
```

## GC Interaction Patterns

### Allocation with Fallback
```c
mp_obj_t safe_create_large_object(size_t size) {
    // Try allocation
    void *buf = m_malloc_maybe(size);

    if (buf == NULL) {
        // Collect and retry
        gc_collect();
        buf = m_malloc_maybe(size);

        if (buf == NULL) {
            // Clear caches or other cleanup
            clear_module_cache();
            gc_collect();
            buf = m_malloc(size);  // Final attempt (raises on failure)
        }
    }

    return mp_obj_new_bytes(buf, size);
}
```

### Preventing Collection
```c
// Disable GC temporarily (use with caution)
void critical_section(void) {
    gc_lock();

    // Allocations here won't trigger GC
    // But may fail if heap full

    gc_unlock();
    // GC may run here if threshold exceeded
}
```

### Manual Memory Management
```c
// Bypass GC for performance-critical code
#include "py/gc.h"

// Allocate outside GC heap
void *raw_ptr = m_malloc_dma(size);  // DMA-capable memory
void *raw_ptr = heap_caps_malloc(size, MALLOC_CAP_32BIT);  // ESP32 specific

// Must manually free
heap_caps_free(raw_ptr);
```

## Debugging Memory Issues

### Track Allocations
```c
#if MICROPY_DEBUG_VERBOSE
#define DEBUG_printf(...) mp_printf(&mp_plat_print, __VA_ARGS__)
#else
#define DEBUG_printf(...)
#endif

void *debug_malloc(size_t size, const char *func) {
    void *ptr = m_malloc(size);
    DEBUG_printf("%s allocated %d bytes at %p\n", func, size, ptr);
    return ptr;
}
```

### Verify Object Validity
```c
// Check if pointer is valid Python object
bool is_valid_obj(mp_obj_t obj) {
    if (mp_obj_is_immediate(obj)) {
        return true;
    }

    // Check if in heap range
    if (!gc_is_heap_pointer(obj)) {
        return false;
    }

    // Verify type pointer
    mp_obj_type_t *type = mp_obj_get_type(obj);
    return (type != NULL && type->name != NULL);
}
```

### Monitor GC Statistics
```c
void print_gc_stats(void) {
    gc_info_t info;
    gc_info(&info);

    mp_printf(&mp_plat_print, "GC stats:\n");
    mp_printf(&mp_plat_print, "  Total: %u\n", info.total);
    mp_printf(&mp_plat_print, "  Used: %u\n", info.used);
    mp_printf(&mp_plat_print, "  Free: %u\n", info.free);
    mp_printf(&mp_plat_print, "  Blocks: %u\n", info.num_blocks);
    mp_printf(&mp_plat_print, "  Max block: %u\n", info.max_block);
}
```

## Soft Reset Behavior

### Heap Cleanup on Soft Reset
```c
// WARNING: All heap objects are destroyed on soft reset
// Static C pointers to heap objects become INVALID

// BAD: Static pointer to heap object
STATIC mp_obj_t cached_object = MP_OBJ_NULL;

void init_module(void) {
    cached_object = mp_obj_new_dict(0);  // Allocated on heap
}

void use_cached(void) {
    // After soft reset, cached_object points to freed memory!
    // This will crash or corrupt memory
    mp_obj_dict_store(cached_object, key, value);  // CRASH!
}
```

### Safe Patterns for Persistent Data

```c
// GOOD: Re-initialize after soft reset
STATIC mp_obj_t cached_object = MP_OBJ_NULL;

// Called after each soft reset
void module_init(void) {
    cached_object = mp_obj_new_dict(0);  // Fresh allocation
}

// GOOD: Check and reinitialize
void use_cached_safe(void) {
    if (cached_object == MP_OBJ_NULL) {
        cached_object = mp_obj_new_dict(0);
    }
    mp_obj_dict_store(cached_object, key, value);
}

// GOOD: Use root pointer that's cleared on reset
MP_REGISTER_ROOT_POINTER(mp_obj_t module_cache);

void module_init(void) {
    // Root pointer automatically cleared on soft reset
    MP_STATE_VM(module_cache) = mp_obj_new_dict(0);
}
```

### What Survives Soft Reset

1. **Static C variables** - Values persist but heap pointers become invalid
2. **BSS/Data segments** - Not cleared
3. **Hardware state** - Often persists (GPIOs, timers, etc.)
4. **Raw malloc() memory** - Platform dependent, usually persists

### What's Destroyed on Soft Reset

1. **Entire GC heap** - All Python objects destroyed
2. **Module dictionaries** - Recreated fresh
3. **Root pointers** - Cleared to NULL/0
4. **Import cache** - Cleared
5. **REPL history** - Cleared

### Reset-Safe Module Design

```c
typedef struct _module_state_t {
    bool initialized;
    uint32_t counter;  // Safe: not a heap pointer
    // mp_obj_t cache;  // UNSAFE: heap pointer
} module_state_t;

STATIC module_state_t module_state;

void check_init(void) {
    if (!module_state.initialized) {
        module_state.initialized = true;
        module_state.counter = 0;
        // Re-create any heap objects here
    }
}

STATIC mp_obj_t module_func(mp_obj_t arg) {
    check_init();  // Always check after reset
    // ... use module_state safely ...
}
```

## Important Considerations

1. **Never store raw pointers to Python objects** - Use mp_obj_t
2. **Register all global Python objects** as root pointers
3. **Static pointers to heap objects become invalid on soft reset**
4. **Always reinitialize heap objects after soft reset**
5. **Protect stack objects** if function might trigger GC
6. **Check allocation success** before use
7. **Free with correct size** when using m_free()
8. **Don't mix allocation APIs** (m_malloc vs malloc)
9. **Be aware of GC timing** in interrupt handlers
10. **Use gc_lock() sparingly** - can cause OOM
11. **Test with gc.threshold(1)** to catch retention bugs
12. **Profile memory usage** in development builds
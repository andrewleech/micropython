# Garbage Collection Behavior

## Mark and Sweep Algorithm

MicroPython uses a tracing garbage collector with two phases:

**CRITICAL: This is a non-relocating, non-compacting collector.**
- Objects are NEVER moved in memory
- Heap is NEVER compacted or defragmented
- Object pointers remain valid for the object's entire lifetime
- Fragmentation can only be resolved by freeing objects

### Mark Phase
1. Start from all root pointers
2. Recursively traverse object references
3. Mark each reachable object as "live"
4. Uses bitmap to track marked status
5. **Objects are NOT moved or relocated**

### Sweep Phase
1. Scan entire heap linearly
2. Reclaim memory from unmarked blocks
3. Reset mark bits for next collection
4. Update free block list
5. **No compaction or defragmentation occurs**

## Root Pointer System

### What Are Root Pointers?
Starting points for the mark phase - objects reachable from roots are never collected.

### Types of Roots

#### Python-Level Roots
- **Module globals**: All module-level variables
- **Main module**: `__main__` module's namespace
- **REPL globals**: Interactive interpreter's namespace
- **Stack frames**: Local variables in active functions
- **Exception state**: Current exception being handled

#### C-Level Roots
Registered via `MP_REGISTER_ROOT_POINTER` macro:
```c
MP_REGISTER_ROOT_POINTER(mp_obj_t my_global_obj);
```

These become fields in `struct _mp_state_vm_t` and are always scanned during GC.

### Root Pointer Chain
An object survives GC if there's a reference chain from any root:
```
Root Pointer → Object A → Object B → Object C
                   ↓
                Object D
```
All objects A, B, C, D survive. Any object not in such a chain is collected.

## GC Triggers

### Automatic Triggers

#### Out of Memory (OOM)
- Primary trigger condition
- Occurs when allocation fails
- Most expensive (several milliseconds)
- Unpredictable timing

#### Threshold-Based
Set via `gc.threshold(bytes)`:
```python
gc.threshold(10000)  # Collect after 10KB allocated
```
- Triggers after N bytes allocated since last GC
- Prevents excessive fragmentation
- More predictable timing
- Trade-off: more frequent but shorter pauses

### Manual Triggers

#### gc.collect()
```python
import gc
gc.collect()  # Force collection now
```
- Explicit control over timing
- Faster when heap not full (~1ms if frequent)
- Best called during idle periods
- Returns number of bytes collected

#### With verbose output
```python
gc.collect(1)  # Print collection statistics
```

## Collection Timing

### Duration Factors
- **Heap size**: Larger heap = longer collection
- **Live objects**: More marking = longer mark phase
- **Fragmentation**: More gaps = longer sweep phase
- **Object complexity**: Deep nesting = longer traversal

### Typical Durations
- **Proactive** (heap not full): ~1ms
- **Reactive** (OOM triggered): 3-10ms
- **Heavy fragmentation**: 10-20ms+
- **First collection**: Often longest

## Object Lifecycle

### Creation
1. Object allocated on heap (unless zero-cost)
2. Immediately usable
3. No reference counting

### Retention
Object retained while:
- Referenced from root pointer
- Referenced by another retained object
- In active scope (stack frame)

### Collection Eligible
Object becomes eligible when:
- No references from roots
- No references from other live objects
- Not in current execution scope

### Actual Collection
- Occurs at next GC cycle
- Memory returned to free pool
- May not immediately reduce mem_alloc()

## Special Considerations

### Circular References
```python
a = []
b = []
a.append(b)
b.append(a)
# Both collected when neither reachable from roots
```
Mark-and-sweep handles cycles correctly (unlike reference counting).

### Weak References
Not supported in most MicroPython ports - all references are strong.

### Finalizers
- Objects with `__del__` methods
- Called before object freed
- Can resurrect objects (not recommended)
- Marked with FTB bit

### Module Import
Imported modules become roots:
```python
import mymodule  # mymodule now a root
```
Module-level variables persist for program lifetime.

## GC State Information

### Query Functions
```python
gc.mem_alloc()  # Bytes currently allocated
gc.mem_free()   # Bytes available
gc.threshold()  # Current threshold setting (-1 if disabled)
```

### Collection Statistics
During `gc.collect(1)`:
```
GC: total: 65536, used: 1312, free: 64224
 No. of 1-blocks: 12, 2-blocks: 3, max blk sz: 8, max free sz: 4014
```

## Common Patterns

### Objects That Persist Unexpectedly
- Check module-level references
- Check class attributes (shared across instances)
- Check default parameter values (evaluated once)
- Check closures capturing variables

### Objects Collected Unexpectedly
- Ensure reference maintained
- Store in module variable if needed long-term
- Pass to functions that need them

### Memory Not Freed After Collection
- Fragmentation preventing large allocations
- Objects still referenced somewhere
- Heap blocks not coalesced yet